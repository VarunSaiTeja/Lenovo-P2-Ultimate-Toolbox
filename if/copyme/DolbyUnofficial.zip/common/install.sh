if $libsinstall || [ "$htc" ] || [ "$axon" ]; then
  mkdir -p $INSTALLER/system/lib $INSTALLER/system/lib64
  cp -f $INSTALLER/custom/lib/* $INSTALLER/system/lib
  cp -f $INSTALLER/custom/lib64/* $INSTALLER/system/lib64
else
  for FILE in "libradio.so" "libradioservice.so"; do
    if [ ! -f "/system/lib/$FILE" ]; then
      mkdir -p $INSTALLER/system/lib $INSTALLER/system/lib64
      cp -f $INSTALLER/custom/lib/$FILE $INSTALLER/system/lib/$FILE
      $IS64BIT && cp -f $INSTALLER/custom/lib64/$FILE $INSTALLER/system/lib64/$FILE
    fi
  done
fi
for FILE in ${CFGS}; do
  if $MAGISK; then
    cp_ch $ORIGDIR$FILE $UNITY$FILE
  else
    [ ! -f $ORIGDIR$FILE.bak ] && cp_ch $ORIGDIR$FILE $UNITY$FILE.bak
  fi
  case $FILE in
    *.conf) sed -i "/effects {/,/^}/ {/^ *music_helper {/,/}/ s/^/#/g}" $UNITY$FILE
            sed -i "/effects {/,/^}/ {/^ *sa3d {/,/^  }/ s/^/#/g}" $UNITY$FILE
            if [ ! "$(grep "vlldp" $UNITY$FILE)" ]; then
              sed -i "s/^libraries {/libraries {\n  vlldp { #$MODID\n    path \/vendor\/lib\/soundfx\/libswvlldp.so\n  } #$MODID/g" $UNITY$FILE
              sed -i "s/^libraries {/libraries {\n  atmos { #$MODID\n    path \/vendor\/lib\/soundfx\/libatmos.so\n  } #$MODID/g" $UNITY$FILE
              sed -i "s/^effects {/effects {\n  vlldp { #$MODID\n    library vlldp\n    uuid 3783c334-d3a0-4d13-874f-0032e5fb80e2\n  } #$MODID/g" $UNITY$FILE
              sed -i "s/^effects {/effects {\n  atmos { #$MODID\n    library atmos\n    uuid 9d4921da-8225-4f29-aefa-aacb40a73593\n  } #$MODID/g" $UNITY$FILE
            fi
            if [ ! "$(sed -n "/^output_session_processing {/,/^}/p" $UNITY$FILE)" ]; then
              echo -e "output_session_processing {\n    music {\n        atmos {\n        }\n    }\n}" >> $UNITY$FILE
            elif [ ! "$(sed -n "/^output_session_processing {/,/^}/ {/music {/,/^    }/p}" $UNITY$FILE)" ]; then
              sed -i "/output_session_processing {/,/^}/ s/output_session_processing {/output_session_processing {\n    music {\n        atmos {\n        }\n    }/" $UNITY$FILE
            elif [ ! "$(sed -n "/^output_session_processing {/,/^}/ {/music {/,/^    }/ {/atmos {/,/}/p}}" $UNITY$FILE)" ]; then
              sed -i "/output_session_processing {/,/^}/ {/music {/,/^    }/ s/music {/music {\n        atmos {\n        }/}" $UNITY$FILE
            fi;;
   *.xml) sed -ri "/^ *<postprocess>$/,/<\/postprocess>/ {/<stream type=\"music\">/,/<\/stream>/ s/^( *)<apply effect=\"music_helper\"\/>/\1<\!--<apply effect=\"music_helper\"\/>-->/}" $UNITY$FILE
          sed -ri "/^ *<postprocess>$/,/<\/postprocess>/ {/<stream type=\"music\">/,/<\/stream>/ s/^( *)<apply effect=\"sa3d\"\/>/\1<\!--<apply effect=\"sa3d\"\/>-->/}" $UNITY$FILE
          if [ ! "$(grep "vlldp" $UNITY$FILE)" ]; then
            sed -i "/<libraries>/ a\        <library name=\"atmos\" path=\"libatmos.so\"\/><!--$MODID-->" $UNITY$FILE
            sed -i "/<libraries>/ a\        <library name=\"vlldp\" path=\"libswvlldp.so\"\/><!--$MODID-->" $UNITY$FILE
            sed -i "/<effects>/ a\        <effect name=\"vlldp\" library=\"vlldp\" uuid=\"3783c334-d3a0-4d13-874f-0032e5fb80e2\"\/><!--$MODID-->" $UNITY$FILE
            sed -i "/<effects>/ a\        <effect name=\"atmos\" library=\"atmos\" uuid=\"9d4921da-8225-4f29-aefa-aacb40a73593\"\/><!--$MODID-->" $UNITY$FILE
          fi
          if [ ! "$(sed -n "/<postprocess>/,/<\/postprocess>/p" $UNITY$FILE)" ]; then     
            sed -i "/<\/audio_effects_conf>/i\    <postprocess>\n       <stream type=\"music\">\n            <apply effect=\"atmos\"\/>\n        <\/stream>\n    <\/postprocess>" $UNITY$FILE
          elif [ ! "$(sed -n "/<postprocess>/,/<\/postprocess>/ {/<stream type=\"music\">/,/<\/stream>/p}" $UNITY$FILE)" ]; then     
            sed -i "/<postprocess>/,/<\/postprocess>/ s/    <postprocess>/    <postprocess>\n        <stream type=\"music\">\n            <apply effect=\"atmos\"\/>\n        <\/stream>/" $UNITY$FILE
          elif [ ! "$(sed -n "/<postprocess>/,/<\/postprocess>/ {/<stream type=\"music\">/,/<\/stream>/ {/^ *<apply effect=\"atmos\"\/>/p}}" $UNITY$FILE )" ]; then
            sed -i "/<postprocess>/,/<\/postprocess>/ {/<stream type=\"music\">/,/<\/stream>/ s/<stream type=\"music\">/<stream type=\"music\">\n            <apply effect=\"atmos\"\/>/}" $UNITY$FILE
          fi;;
  esac   
done
